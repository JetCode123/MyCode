//
//  DB.m
//  MyChineseName
//
//  Created by 818 818 on 10-7-27.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "DB.h"
#import <PlausibleDatabase/PlausibleDatabase.h>
#define kDBPath @"MyChineseName.sqlite"
static PLSqliteDatabase * dbPointer;


@implementation DB
//单例
/** setup sqlite db **/
+ (PLSqliteDatabase *) setup {
    
	if (dbPointer) {
		return dbPointer;
	}
	
	NSLog(@"%@", NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES));
    
	NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
	NSString *realPath = [documentPath stringByAppendingPathComponent:kDBPath];
	
	NSString *srcPath = [[NSBundle mainBundle] pathForResource:@"MyChineseName" ofType:@"sqlite"];
		
	NSFileManager *fileManager = [NSFileManager defaultManager];
	
	if (![fileManager fileExistsAtPath:realPath]) 
	{
		NSError *error;
		if (![fileManager copyItemAtPath:srcPath toPath:realPath error:&error]) {		
			NSLog(@"When setup db: %@", [error localizedDescription]);	
		}
	}
    
	NSLog(@"setup db at path:%@", realPath);
    
	//内部是对realPath 进行转化编码，并且传入dbPointer指针
    dbPointer = [[PLSqliteDatabase alloc] initWithPath: realPath];
	BOOL re = [dbPointer open];
	NSLog(@"db open ok?: %d", re);
    
	//sqlite3_open([realPath UTF8String], &dbPointer);
	return dbPointer;
}

/** close sqlite pointer **/
+ (void) close {
	if (dbPointer) {
        [dbPointer close];
		//sqlite3_close(dbPointer);
		dbPointer = NULL;
	}
}


@end
