//
//  chineseName.h
//  MyChineseName
//
//  Created by 818 818 on 10-7-27.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface chineseName : NSObject {
	
	NSString  *m_englishName;
	NSString  *m_chineseName;
	NSString  *m_firstWord;
	NSString  *m_nameMeaning;
	NSString  *m_sex;
	
	
}


+(NSMutableArray *)findAllFirstWord;

+(NSMutableArray *)findAllNamesWithSameFirstWord:(NSString *)firstWord;

+(NSString *)nameTransition:(NSString *)englishname;

+(NSMutableArray *)findAllNames;
//-(id)initWithEName:(NSString *)eName cName:(NSString *)cName firstWord:(NSString *)firstWord meaning:(NSString *)meaning AndSex:(NSString *)sex;

//-(NSString *)EnglishName;
//-(NSString *)ChineseName;
//-(NSString *)firstWord;
//-(NSString *)meaning;
//-(NSString *)sex;

@end
