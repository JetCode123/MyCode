//
//  main.m
//  MyChineseName
//
//  Created by 818 818 on 10-9-29.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"MyChineseNameAppDelegate");
    [pool release];
    return retVal;
}
