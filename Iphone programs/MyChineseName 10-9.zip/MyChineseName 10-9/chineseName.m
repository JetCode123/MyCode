//
//  chineseName.m
//  MyChineseName
//
//  Created by 818 818 on 10-7-27.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "chineseName.h"
#import "DB.h"

@implementation chineseName

//fetch all the first name into an array


+(NSMutableArray *)findAllFirstWord
{
	NSString *firstString;
	PLSqliteDatabase *db=[DB setup];
	
	id<PLResultSet> rs;
	
	rs=[db executeQuery:@"select distinct firstWord from myChineseName"];
	
	NSMutableArray *firstWord=[NSMutableArray new];
	
	while([rs next])
	{
		firstString=[rs objectForColumn:@"firstWord"];
		[firstWord addObject:firstString];
	}
	
	[rs close];
	NSLog(@"firstWord count=%d",[firstWord count]);
	return [firstWord autorelease];
}


+(NSMutableArray *)findAllNamesWithSameFirstWord:(NSString *)firstWord
{
	NSString *englishName;
	PLSqliteDatabase *db=[DB setup];
	
	id <PLResultSet> rs;
	
	rs=[db executeQuery:@"select distinct englishName from myChineseName where firstWord=?",firstWord];
	
	NSMutableArray *allNames=[NSMutableArray new];
	
	while([rs next])
	{
		englishName=[rs objectForColumn:@"englishName"];
		[allNames addObject:englishName];
		
	}	
	NSLog(@"allNames count=%d",[allNames count]);
	[rs close];
	
	return [allNames autorelease];
}

+(NSString *)nameTransition:(NSString *)englishName
{
	NSString *c_name;
	PLSqliteDatabase *db=[DB setup];
	id<PLResultSet> rs;
	rs=[db executeQuery:@"select chineseName from myChineseName where englishName=?",englishName];
	
	while([rs next])
	{
		c_name=[rs objectForColumn:@"chineseName"];
	}
	return c_name;
	[rs close];
}

+(NSMutableArray *)findAllNames
{
	PLSqliteDatabase *db=[DB setup];
	id<PLResultSet> rs;
	NSMutableArray *allNames=[NSMutableArray new];
	rs=[db executeQuery:@"select englishName from myChineseName"];
	while([rs next])
	{
		NSString *englishName=[rs objectForColumn:@"englishName"];
		[allNames addObject:englishName];
	}
	[rs close];
	return [allNames autorelease];
}

//-(NSString *)EnglishName
//{
//	return m_englishName;
//}
//-(NSString *)ChineseName
//{
//	return m_chineseName;
//}
//-(NSString *)firstWord   NSArray
//{
//	return m_firstWord;
//}
//-(NSString *)meaning
//{
//	return m_nameMeaning;
//}
//-(NSString *)sex
//{
//	return m_sex;
//}

@end
