//
//  LabelName.m
//  MyChineseName
//
//  Created by 818 818 on 10-8-10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "LabelName.h"

@implementation LabelName
@synthesize nameLabel;
@synthesize colorImageView;
@synthesize nameSize;

-(id)init
{
	if(self=[super init])
	{
		
		subViewIsVisible=YES;
		isChanged=NO;
		self.nameSize=35;
		self.frame=CGRectMake(0,0,320,460);
		self.userInteractionEnabled=YES;
		NSLog(@"self.multipleTouchEnabled=%d",self.multipleTouchEnabled);
		self.multipleTouchEnabled=YES;
		self.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"Default.png"]];
		self.backgroundColor=[UIColor clearColor];
		
		colorImageView=[[UIImageView alloc] initWithFrame:CGRectMake(2,316,316,90)];
		colorImageView.backgroundColor=[UIColor clearColor];
		colorImageView.image=[UIImage imageNamed:@"textedit_color1.png"];
		[self addSubview:colorImageView];
		
		nameLabel=[[UILabel alloc] initWithFrame:CGRectMake(50,210,180,90)];
		nameLabel.backgroundColor=[UIColor clearColor];
		
		//nameLabel.font=[UIFont fontWithName:@"Arial-BoldItalicMT" size:nameSize];
		nameLabel.font=[UIFont fontWithName:@"AmericanTypewriter-Bold" size:nameSize];
		nameLabel.textColor=[UIColor blackColor];
		nameLabel.textAlignment=UITextAlignmentCenter;
		nameLabel.numberOfLines=0;
		nameLabel.multipleTouchEnabled=YES;
		nameLabel.userInteractionEnabled=YES;
		centerX=nameLabel.center.x;
		centerY=nameLabel.center.y;
		
		
		[self addSubview:nameLabel];
		[nameLabel release];
	}
	return self;
}

-(void)setImage:(UIImage *)image
{
	self.backgroundColor=[UIColor colorWithPatternImage:image];
}

-(void)changeHV
{
	CGSize expectedLabelSize;
	
	NSLog(@"%d",isChanged);
	if(isChanged==YES)
	{
		expectedLabelSize = [[nameLabel text] sizeWithFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size:nameSize] 
										 constrainedToSize: CGSizeMake( MAXFLOAT , nameSize)
											 lineBreakMode:UILineBreakModeCharacterWrap];		
	}
	
	else
	{
		expectedLabelSize = [[nameLabel text] sizeWithFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size:nameSize] 
										 constrainedToSize: CGSizeMake( nameSize , MAXFLOAT)
											 lineBreakMode:UILineBreakModeCharacterWrap];		
	}
	
	[nameLabel setFrame:CGRectMake(nameLabel.frame.origin.x,nameLabel.frame.origin.y,expectedLabelSize.width,expectedLabelSize.height)];
	nameLabel.center=CGPointMake(centerX,centerY);
	
	
	isChanged=!isChanged;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{	
	
	UITouch *touch=[touches anyObject];
	startPoint=[touch locationInView:self];	
	
	
	if(subViewIsVisible)
	{
		if(CGRectContainsPoint(colorImageView.frame, startPoint))
		{	
			[self setColorTheX:(NSInteger)((startPoint.x-7.5)/39+1) theY:(NSInteger)((startPoint.y-5.5-363)/39+1)];
			subViewIsVisible=!subViewIsVisible;
			
			if(CGRectContainsPoint(CGRectMake(253,331,60,60), startPoint))
			{
				[self changeHV];
			}
		}		
		else
		{
			if(CGRectContainsPoint(nameLabel.frame, startPoint))
			{
				
				for(id v in [self subviews])
				{
					[v setAlpha:1.0];
					//[v setAlpha:0.0];
				}
			}
			else
			{
				for(id v in [self subviews])
				{
					[v setAlpha:0.0];
				}
			}
		}
	}	
	else
	{
		if(CGRectContainsPoint(nameLabel.frame, startPoint))
		{
			for(id v in [self subviews])
			{
				//[v setAlpha:0.0];
				[v setAlpha:1.0];
				subViewIsVisible=YES;
			}
		}
		else
		{
			for(id v in [self subviews])
			{
				[v setAlpha:1.0];
				
			}
		}
	}
	
	
	subViewIsVisible=!subViewIsVisible;
	[nameLabel setAlpha:1.0];
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	colorImageView.alpha=0.0;
	
	NSArray *theTouches=[touches allObjects];
	if([theTouches count]==2)
	{
		UITouch *touch1=[theTouches objectAtIndex:0];
		UITouch *touch2=[theTouches objectAtIndex:1];
		
		CGPoint previousLocation1=[touch1 previousLocationInView:self];
		CGPoint currentLocation1=[touch1 locationInView:self];
		
		CGPoint previousLocation2=[touch2 previousLocationInView:self];
		CGPoint currentLocation2=[touch2 locationInView:self];
		
		//纵向缩放
		if(isChanged==YES)
		{
			if(fabs(previousLocation2.x-previousLocation1.x)>fabs(currentLocation2.x-currentLocation1.x)
			   ||fabs(previousLocation1.y-previousLocation2.y)>fabs(currentLocation1.y-currentLocation2.y))
			{
				if(self.nameSize>0)
				{
					
					
					self.nameSize=nameSize-2;
					
					[nameLabel setFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size:nameSize]];
					CGSize expectedLabelSize=[[nameLabel text] sizeWithFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size:nameSize]
														  constrainedToSize:CGSizeMake(nameSize,MAXFLOAT)
															  lineBreakMode:UILineBreakModeCharacterWrap];
					
					nameLabel.frame=CGRectMake(nameLabel.frame.origin.x,nameLabel.frame.origin.y,expectedLabelSize.width,expectedLabelSize.height);
					nameLabel.center=CGPointMake(centerX,centerY);
					
				}
			}
			
			if (fabs(previousLocation2.x -previousLocation1.x) < fabs(currentLocation1.x -currentLocation2.x) 
				|| fabs(previousLocation2.y -previousLocation1.y) < fabs(currentLocation1.y -currentLocation2.y)) 
			{
				
				self.nameSize = nameSize +2;
				[nameLabel setFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size: nameSize]];
				CGSize expectedLabelSize = [[nameLabel text] sizeWithFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size:nameSize] 
														constrainedToSize: CGSizeMake( nameSize , MAXFLOAT)
															lineBreakMode:UILineBreakModeCharacterWrap];
				
				[nameLabel setFrame:CGRectMake( nameLabel.frame.origin.x, nameLabel.frame.origin.y, expectedLabelSize.width, expectedLabelSize.height)];
				[nameLabel setCenter:CGPointMake(centerX, centerY)];
				
				if(nameLabel.frame.size.height>=367)
				{
					self.nameSize=nameSize-2;
					[nameLabel setFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size: nameSize]];
					CGSize expectedLabelSize1 = [[nameLabel text] sizeWithFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size:nameSize] 
															 constrainedToSize: CGSizeMake( nameSize , MAXFLOAT)
																 lineBreakMode:UILineBreakModeCharacterWrap];
					
					[nameLabel setFrame:CGRectMake( nameLabel.frame.origin.x, nameLabel.frame.origin.y, expectedLabelSize1.width, expectedLabelSize1.height)];
					[nameLabel setCenter:CGPointMake(centerX, centerY)];
				}
			}
		}
		
		//横向缩放
		if(isChanged==NO)
		{
			if (fabs(previousLocation2.x - previousLocation1.x ) > fabs(currentLocation1.x -currentLocation2.x) 
				|| fabs(previousLocation2.y -previousLocation1.y)>fabs(currentLocation1.y -currentLocation2.y)) 
			{
				if(self.nameSize>0)
				{
					
					self.nameSize = nameSize -2;
					
					[nameLabel setFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size: nameSize]];
					CGSize expectedLabelSize = [[nameLabel text] sizeWithFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size:nameSize] 
															constrainedToSize: CGSizeMake( MAXFLOAT, nameSize)
																lineBreakMode:UILineBreakModeCharacterWrap];
					[nameLabel setFrame:CGRectMake( nameLabel.frame.origin.x, nameLabel.frame.origin.y, expectedLabelSize.width, expectedLabelSize.height)];
					[nameLabel setCenter:CGPointMake(centerX, centerY)];
					
				}
			}
			
			if (fabs(previousLocation2.x -previousLocation1.x) < fabs(currentLocation1.x -currentLocation2.x) 
				|| fabs(previousLocation2.y -previousLocation1.y) < fabs(currentLocation1.y -currentLocation2.y)) 
			{
				
				self.nameSize = nameSize +2;
				[nameLabel setFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size: nameSize]];
				CGSize expectedLabelSize = [[nameLabel text] sizeWithFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size:nameSize] 
														constrainedToSize: CGSizeMake( MAXFLOAT , nameSize)
															lineBreakMode:UILineBreakModeCharacterWrap];
				
				[nameLabel setFrame:CGRectMake( nameLabel.frame.origin.x, nameLabel.frame.origin.y, expectedLabelSize.width, expectedLabelSize.height)];
				[nameLabel setCenter:CGPointMake(centerX, centerY)];
				
				if(nameLabel.frame.size.width>=320)
				{
					self.nameSize=nameSize-2;
					[nameLabel setFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size: nameSize]];
					CGSize expectedLabelSize1 = [[nameLabel text] sizeWithFont:[UIFont fontWithName:@"Arial-BoldItalicMT" size:nameSize] 
															 constrainedToSize: CGSizeMake( MAXFLOAT , nameSize)
																 lineBreakMode:UILineBreakModeCharacterWrap];
					
					[nameLabel setFrame:CGRectMake( nameLabel.frame.origin.x, nameLabel.frame.origin.y, expectedLabelSize1.width, expectedLabelSize1.height)];
					[nameLabel setCenter:CGPointMake(centerX, centerY)];
				}
				
				
			}
		}
	}
	else
	{
		UITouch *touch=[touches anyObject];
		CGPoint previousLocation=[touch previousLocationInView:self];
		CGPoint currentLocation=[touch locationInView:self];
		float newX=nameLabel.frame.origin.x+currentLocation.x-previousLocation.x;
		float newY=nameLabel.frame.origin.y+currentLocation.y-previousLocation.y;
		float right=newX+nameLabel.frame.size.width;
		float bottom=newY+nameLabel.frame.size.height;
		//左边
		
		if(newX<0)
		{
			newX=0;
		}
		//右边
		else if(right>320)
		{
			newX=320-nameLabel.frame.size.width;
		}
		//上边
		if(newY<44)
		{
			newY=44;
		}
		//下边
		else if(bottom>411)
		{
			newY=411-nameLabel.frame.size.height;
		}		
		
		
		if(CGRectContainsPoint(nameLabel.frame, currentLocation))
		{
			[nameLabel setFrame:CGRectMake(newX,newY
										   ,nameLabel.frame.size.width,
										   nameLabel.frame.size.height)];
			centerX=nameLabel.center.x;
			centerY=nameLabel.center.y;
		}
	}
}


- (void)setColorTheX:(NSInteger)theX theY:(NSInteger)theY {
	if (1 ==theY)
	{
		switch (theX) {
			case 1:
				[self.nameLabel setTextColor:[UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:1.0]];
				break;
			case 2:
				[self.nameLabel setTextColor:[UIColor brownColor]];
				break;
			case 3:
				[self.nameLabel setTextColor:[UIColor orangeColor]];
				break;
			case 4:
				[self.nameLabel setTextColor:[UIColor cyanColor]];
				break;
			case 5:
				[self.nameLabel setTextColor:[UIColor magentaColor]];
				break;
			case 6:
				[self.nameLabel setTextColor:[UIColor purpleColor]];
				break;
			default:
				break;
		}
	}
	else {
		switch (theX) {
			case 1:
				[self.nameLabel setTextColor:[UIColor whiteColor]];
				break;
			case 2:
				[self.nameLabel setTextColor:[UIColor blackColor]];
				break;
			case 3:
				[self.nameLabel setTextColor:[UIColor redColor]];
				break;
			case 4:
				[self.nameLabel setTextColor:[UIColor yellowColor]];
				break;
			case 5:
				[self.nameLabel setTextColor:[UIColor blueColor]];
				break;
			case 6:
				[self.nameLabel setTextColor:[UIColor greenColor]];
				break;
			default:
				break;
		}
	}
}

- (void)drawRect:(CGRect)rect {
}


- (void)dealloc {
	[nameLabel release];
	[colorImageView release];
	[super dealloc];
}


@end
