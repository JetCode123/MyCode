//
//  MyChineseNameAppDelegate.h
//  MyChineseName
//
//  Created by 818 818 on 10-9-29.
//  Copyright __MyCompanyName__ 2010. All rights reserved.		NSFileManager		NSNumber	NSString 
//

#import <UIKit/UIKit.h>

@class BeginViewController;
@interface MyChineseNameAppDelegate : NSObject <UIApplicationDelegate> {
		UIWindow *window;
		BeginViewController *_beginVC;
	
}

@property (nonatomic, retain)  UIWindow *window;
@property (nonatomic,retain) BeginViewController *_beginVC;

-(UIWindow *)returnWindow;

-(void)getUserDefaults;
-(void)setUserDefaults:(NSNumber *)imageNumber;

-(void)setSelectedUserDefaults:(NSNumber *)number;
-(BOOL)getSelectedUserDefaults;


//File operation
-(NSString *)documentsPath;
-(NSString *)readFromFile:(NSString *)filePath;
-(void)writeToFile:(NSString *)text withFileName:(NSString *)filePath;

@end


