//
//  RootViewController.h
//  MyChineseName
//
//  Created by 818 818 on 10-9-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FirstViewController;
@interface RootViewController : UIViewController {

	FirstViewController *_firstVC;
	UINavigationController *navController;
	UITabBarController *_tabBarCtrl;
}

@property(nonatomic,retain)FirstViewController *_firstVC;
@property(nonatomic,retain) UITabBarController *_tabBarCtrl;

-(void)setAlphaZero;

-(void)setAlphaOne;

@end
