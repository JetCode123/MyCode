//
//  BeginViewController.h
//  MyChineseName
//
//  Created by 818 818 on 10-9-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.       NSDictionary
//

#import <UIKit/UIKit.h>


@interface BeginViewController : UIViewController {

	UIScrollView *_scrollView;
	UILabel *_label;
	UIButton *_enterButton;
	UIImageView *_blank;
	UIImageView *_select;
	BOOL isSelected;
}

@end
