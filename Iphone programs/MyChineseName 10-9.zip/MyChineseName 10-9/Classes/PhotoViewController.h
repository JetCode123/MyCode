//
//  PhotoViewController.h
//  MyChineseName
//
//  Created by 818 818 on 10-10-9.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PhotoViewController : UIViewController <UINavigationControllerDelegate,UIImagePickerControllerDelegate> 
{
	
	UIImagePickerController *_picker;
	
	UINavigationBar *_photoNavBar;
//	UILabel *_photoLabel;
	UITabBarController *_photoTabBarController;
}
@property(nonatomic,retain) UITabBarController *_photoTabBarController;


-(void)displayPhotoAlbum;
@end
