//
//  MainViewController.m
//  MyChineseName
//
//  Created by 818 818 on 10-9-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"
#import "BackgroundViewController.h"
#import "RootViewController.h"
#import "PhotoViewController.h"
@implementation MainViewController

-(id)init
{
	if(self=[super init])
	{
		[[UIApplication sharedApplication] setStatusBarHidden:NO];
		[[UIApplication sharedApplication] setStatusBarStyle:UIBarStyleBlackTranslucent];

		self.view.frame=[[UIScreen mainScreen] bounds];
		NSMutableArray *controllersArray=[NSMutableArray array];
		_tabBarController=[[UITabBarController alloc] init];
		
//		FirstViewController *_firstVC=[[FirstViewController alloc] init];
//		_firstVC.tabBarItem=[[UITabBarItem alloc] initWithTitle:@"All Names" image:[UIImage imageNamed:@"j.png"] tag:0];
//		[controllersArray addObject:_firstVC];
//		[_firstVC release];
		
		BackgroundViewController *bgController=[[BackgroundViewController alloc] init];
		bgController.tabBarItem=[[UITabBarItem alloc] initWithTitle:@"Wallpaper" image:[UIImage imageNamed:@"121-lanscape.png"] tag:2];
		bgController.m_bgBarController=_tabBarController;
		bgController.window=window;
		[controllersArray addObject:bgController];
		[bgController release];

		PhotoViewController *_photoVC=[[PhotoViewController alloc] init];
		_photoVC.tabBarItem=[[UITabBarItem alloc] initWithTitle:@"Photos" image:[UIImage imageNamed:@"3.png"] tag:4];
		_photoVC._photoTabBarController=_tabBarController;
		[controllersArray addObject:_photoVC];
		[_photoVC release];
		
		
		RootViewController *_rootVC=[[RootViewController alloc] init];
		_rootVC.tabBarItem=[[UITabBarItem alloc] initWithTitle:@"All Names" image:[UIImage imageNamed:@"j.png"] tag:0];
		_rootVC._tabBarCtrl=_tabBarController;
		[controllersArray insertObject:_rootVC atIndex:0];
		[_rootVC release];
		
		[_tabBarController setViewControllers:controllersArray];
		[self.view addSubview:_tabBarController.view];
		[self.view.window bringSubviewToFront:_tabBarController.view];
		
	}
	return self;
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
