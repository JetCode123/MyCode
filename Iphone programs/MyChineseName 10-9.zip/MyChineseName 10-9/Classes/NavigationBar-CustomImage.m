

#import "NavigationBar-CustomImage.h"
@implementation UINavigationBar(CustomImage)

-(void)setBackground:(NSString *)imgName
{
	view=[[UIImageView alloc] initWithFrame:CGRectMake(0,0,320,44)];
	view.image=[UIImage imageNamed:imgName];
	view.contentMode=UIViewContentModeScaleToFill;
	//[self addSubview:view];
	[self insertSubview:view atIndex:0];
}

@end
