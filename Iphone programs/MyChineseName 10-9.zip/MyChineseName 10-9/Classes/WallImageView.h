//
//  WallImageView.h
//  MyChineseName
//
//  Created by 818 818 on 10-9-14.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BackgroundViewController;
@interface WallImageView : UIImageView {
	
	UIImage *wallpaperImage;
	BackgroundViewController *theBack;
	CGPoint center;
	UIImageView *showView;
	UIView *redview1,*redview2,*redview3,*redview4;
}

-(void)setWallpaperTheX:(NSInteger)theX TheY:(NSInteger)theY;

@property(nonatomic,retain) BackgroundViewController *theBack;

@end
