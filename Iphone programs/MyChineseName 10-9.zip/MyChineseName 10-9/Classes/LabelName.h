//
//  LabelName.h
//  MyChineseName
//
//  Created by 818 818 on 10-8-10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LabelName : UIView {
	
	UIImageView *colorImageView;
	UILabel *nameLabel;
	
	BOOL subViewIsVisible;
	BOOL isChanged;
	float centerX;
	float centerY;
	NSInteger nameSize;
	CGPoint startPoint;
	
}

@property(nonatomic,retain) UILabel *nameLabel;
@property(nonatomic,retain) UIImageView *colorImageView;
@property(nonatomic)  NSInteger nameSize;

- (void)setColorTheX:(NSInteger)theX theY:(NSInteger)theY;
-(void)setImage:(UIImage *)image;                                              
@end
