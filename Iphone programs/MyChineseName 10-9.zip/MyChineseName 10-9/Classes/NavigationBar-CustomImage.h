

#import <UIKit/UIKit.h>
@interface UINavigationBar(CustomImage)
UIImageView *view;
-(void)setBackground:(NSString *)imgName;
@end