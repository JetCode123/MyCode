//
//  NameEditViewController.m
//  MyChineseName
//
//  Created by 818 818 on 10-8-2.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "NameEditViewController.h"
#import "NavigationBar-CustomImage.h"
#import "LabelName.h"
#import "RootViewController.h"
#import "QuartzCore/QuartzCore.h"
static int i=-1;
@implementation NameEditViewController


@synthesize nameEditBar;
-(id)init
{
	if(self=[super init])
	{		
		
//		NSArray *familys=[UIFont familyNames];
//		for(int i=0;i<[familys count];i++)
//		{
//			NSString *family=[familys objectAtIndex:i];
//			NSLog(@"\r\n\r\nFontFamily:==%@",family);
//			NSArray *fonts=[UIFont fontNamesForFamilyName:family];
//			for(int j=0;j<[fonts count];j++)
//			{
//				NSLog(@"%@",[fonts objectAtIndex:j]);
//			}
//		}
		
		self.view.frame=[[UIScreen mainScreen] bounds];

		nameEditBar=[[UINavigationBar alloc] initWithFrame:CGRectMake(0,0,320,44)];
	
		nameEditBar.barStyle=UIBarStyleBlackTranslucent;
	
		[nameEditBar setBackground:@"barImg1-1.png"];
		
		[self.view addSubview:nameEditBar];   
		[nameEditBar release];
		
		__nameLabel=[[UILabel alloc] initWithFrame:CGRectMake(80,7,160,30)];
		__nameLabel.textColor=[UIColor colorWithRed:0.0 green:0.666 blue:0.888 alpha:1.0];
		__nameLabel.backgroundColor=[UIColor clearColor];
		__nameLabel.textAlignment=UITextAlignmentCenter;

		__nameLabel.font=[UIFont fontWithName:@"AmericanTypewriter-Bold" size:23.f];
		[nameEditBar addSubview:__nameLabel];
		[__nameLabel release];
		
		flipButton=[UIButton buttonWithType:UIButtonTypeCustom];
		flipButton.frame=CGRectMake(2,1,42,42);
		[flipButton setBackgroundImage:[UIImage imageNamed:@"back1.png"] forState:UIControlStateNormal];
		[flipButton setBackgroundImage:[UIImage imageNamed:@"back2.png"] forState:UIControlStateHighlighted];
		[flipButton addTarget:self action:@selector(flipBack) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:flipButton];

		
//		NSArray *segmentChoice=[NSArray arrayWithObjects:@"Save",nil];
//		saveSegmentControl=[[UISegmentedControl alloc] initWithItems:segmentChoice];
//		saveSegmentControl.frame=CGRectMake(206.5,60,50,25);
//		[saveSegmentControl addTarget:self action:@selector(segmentControlAction) forControlEvents:UIControlEventValueChanged];
//		saveSegmentControl.segmentedControlStyle = UISegmentedControlStyleBar;
//		saveSegmentControl.selectedSegmentIndex=-1;
//		//segmentControl.tintColor = [UIColor colorWithRed:0.70 green:0.171 blue:0.1 alpha:1.0];
//		saveSegmentControl.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"r2.png"]];
//		saveSegmentControl.tintColor=[UIColor clearColor];
//		//saveSegmentControl.tintColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"r1.png"]];
//		NSLog(@"the default select no. is %d",saveSegmentControl.selectedSegmentIndex);
//		[self.view addSubview:saveSegmentControl];
//		[saveSegmentControl release];
		
		saveButton=[UIButton buttonWithType:UIButtonTypeCustom];
		saveButton.frame=CGRectMake(206.5,60,50,25);
		saveButton.titleLabel.font=[UIFont boldSystemFontOfSize:12.f];
		saveButton.titleLabel.textAlignment=UITextAlignmentCenter;
		[saveButton setTitle:@"SAVE" forState:UIControlStateNormal];
		[saveButton setBackgroundImage:[UIImage imageNamed:@"r2.png"] forState:UIControlStateNormal];
		[saveButton setBackgroundImage:[UIImage imageNamed:@"r1.png"] forState:UIControlStateHighlighted];
		[saveButton addTarget:self action:@selector(segmentControlAction) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:saveButton];
		
//		NSArray *segmentChoice1=[NSArray arrayWithObjects:@"Photos",nil];
//		segmentControl1=[[UISegmentedControl alloc] initWithItems:segmentChoice1];
//		segmentControl1.frame=CGRectMake(256.5,60,51,25);
//		[segmentControl1 addTarget:self action:@selector(segmentAction) forControlEvents:UIControlEventValueChanged];
//		segmentControl1.segmentedControlStyle = UISegmentedControlStyleBar;
//		segmentControl1.selectedSegmentIndex=-1;
//		segmentControl1.tintColor = [UIColor colorWithRed:0.171 green:0.171 blue:0.80 alpha:1.0];
//		
//		[self.view addSubview:segmentControl1];
//		[segmentControl1 release];
		
		openButton=[UIButton buttonWithType:UIButtonTypeCustom];
		openButton.frame=CGRectMake(256.5,60,50,25);
		openButton.titleLabel.font=[UIFont boldSystemFontOfSize:12.f];
		openButton.titleLabel.textAlignment=UITextAlignmentCenter;
		[openButton setTitle:@"OPEN" forState:UIControlStateNormal];
		[openButton setBackgroundImage:[UIImage imageNamed:@"b2.png"] forState:UIControlStateNormal];
		[openButton setBackgroundImage:[UIImage imageNamed:@"b1.png"] forState:UIControlStateHighlighted];
		[openButton addTarget:self action:@selector(segmentAction) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:openButton];
	}
	return self;
}

-(void)getName:(NSString *)name
{
	__nameLabel.text=name;
}



-(void)viewDidLoad
{
	m_labelNameView=[[LabelName alloc] init];
	
	[self.view addSubview:m_labelNameView];
	
	[m_labelNameView release];
}


-(void)segmentControlAction
{
	
//	if([segmentControl selectedSegmentIndex]==0)
//	{
		alert=[[UIAlertView alloc] initWithTitle:nil message:@"Do you want to save it now?" delegate:self cancelButtonTitle:@"Yes" otherButtonTitles:@"Later",nil];
		[alert show];
		[alert release];
//	}
	
}

-(void)segmentAction
{
//	if([segmentControl1 selectedSegmentIndex]==0)
//	{
		m_labelNameView.colorImageView.alpha=1;
		UIImagePickerController	*imagePicker=[[UIImagePickerController alloc] init];
		if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
		{
			imagePicker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
			imagePicker.delegate=self;
			[self presentModalViewController:imagePicker animated:YES];
			
			[imagePicker release];
		}
//	}
	
//	[segmentControl1 setSelectedSegmentIndex:-1];
}

#pragma mark ==
#pragma mark UIImagePickerControllerDelegate method
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	[picker dismissModalViewControllerAnimated:YES];
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo

{
	
	[picker dismissModalViewControllerAnimated:YES];
	[m_labelNameView.window setBackgroundColor:[UIColor colorWithPatternImage:image]];
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if(alertView==alert)
	{
		if(buttonIndex==0)
		{
			m_labelNameView.colorImageView.alpha=0.0;
			
			[self performSelector:@selector(displaySaving) withObject:nil afterDelay:0.5];
		}
		else
		{
			//[segmentControl setSelectedSegmentIndex:-1];
		}
	}
	
	if(alertView==alert1)
	{
		//[segmentControl setSelectedSegmentIndex:-1];
		[saveSheet removeFromSuperview];
		i=-1;
		[m_labelNameView addSubview:m_labelNameView.colorImageView];
	}
}

-(void)displaySaving
{
	
	saveSheet=[[UIActionSheet alloc] initWithTitle:@"Please wait\n\n\n\n" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil];
	saveSheet.actionSheetStyle=UIActionSheetStyleBlackTranslucent;
	progress=[[UIProgressView alloc] initWithFrame:CGRectMake(55, 70, 188,10)]; 
	progress.progressViewStyle=UIProgressViewStyleDefault;
	progress.progress=0.0;
	[saveSheet addSubview:progress];
	
	ai=[[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0,0,24.f,24.f)];
	ai.center=CGPointMake(160,50);
	ai.activityIndicatorViewStyle=UIActivityIndicatorViewStyleWhiteLarge;
	[saveSheet addSubview:ai];
	[ai release];
	[ai startAnimating];
	
	showLabel=[[UILabel alloc] initWithFrame:CGRectMake(255,53,50,40)];
	showLabel.textColor = [UIColor whiteColor];
	showLabel.backgroundColor=[UIColor clearColor]; 
	showLabel.textAlignment=UITextAlignmentCenter;
	showLabel.font=[UIFont fontWithName:@"Arial" size:15.f];
	[saveSheet addSubview:showLabel];
	[showLabel release];
	
	[NSTimer scheduledTimerWithTimeInterval:0.005 target:self selector:@selector(update:) userInfo:nil repeats:YES];
	
	[saveSheet showInView:self.view];
	
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)index
{
	[actionSheet release]; 
}

-(void)update:(NSTimer *)timer 
{
	progress.progress+=0.01;
	
	
	i++;
	NSString *intString=[NSString stringWithFormat:@"%d",i];
	showLabel.text=[intString stringByAppendingFormat:@"%@",@"%"];  
	
	if(i==100)
	{
		[self performSelector:@selector(stop) withObject:nil afterDelay:1.2];
		[self save];
		[timer invalidate];
		
		[ai stopAnimating];
		[saveSheet setTitle:@"Done it!"];
		
		for(UIView *view in [self.view.window subviews])
		{
			view.alpha=1.0;
		}
		
		for(UIView *view in [self.view subviews])
		{
			view.alpha=1.0;
		}
		
		[self performSelector:@selector(displayOver) withObject:nil afterDelay:0.43];
	}
}

-(void)save
{	
	UIGraphicsBeginImageContext(m_labelNameView.window.bounds.size);

	
	for(UIView *view in [self.view.window subviews])
	{
		view.alpha=0.0;
	}
	[self.view.window.layer renderInContext:UIGraphicsGetCurrentContext()];
	
	for(UIView *view in [self.view subviews])
	{
		if([view isKindOfClass:[LabelName class]])
		{
			view.alpha=1.0;
		}
		else
		{
			view.alpha=0.0;
		}
	}
	[self.view.layer renderInContext:UIGraphicsGetCurrentContext()];

	UIImage *saveImage=UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	UIImageWriteToSavedPhotosAlbum(saveImage, nil, nil, nil); 
}
-(void)displayOver
{	

	alert1=[[UIAlertView alloc] initWithTitle:@"Information" message:@"Added to photos!" delegate:self cancelButtonTitle:@"Okey" otherButtonTitles:nil];
	[alert1 show];
	[alert1 release];
}

-(void)flipBack
{
	m_root=[[RootViewController alloc] init];
	m_root.modalTransitionStyle=UIModalTransitionStyleCrossDissolve;
	[m_root.navigationController setNavigationBarHidden:NO animated:NO];
	[self presentModalViewController:m_root animated:YES];
	[m_root release];
//	m_first=[[FirstViewController alloc] init];
//	m_first.modalTransitionStyle=UIModalTransitionStyleCrossDissolve;
//	[self presentModalViewController:m_first animated:YES];
//	[m_first release];
}

-(void)getLabelName:(NSString *)name 
{
	m_labelNameView.nameLabel.text=name;
}

-(void)stop
{
	[saveSheet dismissWithClickedButtonIndex:0 animated:YES]; 
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[nameEditBar release];
	//[m_editBarController release];
    [super dealloc];
}


@end
