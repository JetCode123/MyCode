//
//  BackgroundViewController.h
//  MyChineseName
//
//  Created by 818 818 on 10-8-3.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class WallImageView;
@interface BackgroundViewController : UIViewController <UIScrollViewDelegate>
{
	UINavigationBar *bgBar;
//	UILabel *_barCustomLabel;

	UIWindow *window;
	
	UITabBarController *m_bgBarController;
	UIImage *wallpaperImage;
	WallImageView *_wallView;
	UIActivityIndicatorView *activityIndicator;
}
@property(nonatomic,retain) UIWindow *window;
@property(nonatomic,retain) UITabBarController *m_bgBarController;
@property(nonatomic,retain) UIActivityIndicatorView *activityIndicator;

-(void)startAnimating;
-(void)stopAnimating;

@end
