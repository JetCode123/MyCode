//
//  MyChineseNameAppDelegate.m
//  MyChineseName
//
//  Created by 818 818 on 10-9-29.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "MyChineseNameAppDelegate.h"
#import "BeginViewController.h"
#import "MainViewController.h"

NSString *kBackgroundImageKey=@"bg_image";
NSString *kSelectedKey=@"selectedNO";
@implementation MyChineseNameAppDelegate

@synthesize window;
@synthesize _beginVC;

-(UIWindow *)returnWindow
{
	window=[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	return window;
}

-(NSString *)documentsPath
{
	NSArray *paths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDir=[paths objectAtIndex:0];
	return documentsDir;
}

-(NSString *)readFromFile:(NSString *)filePath
{
	if([[NSFileManager defaultManager] fileExistsAtPath:filePath])
	{
		NSArray *array=[[NSArray alloc] initWithContentsOfFile:filePath];
		NSString *data=[[NSString alloc] initWithFormat:@"%@",[array objectAtIndex:0]];
		[array release];
		return data;
	}
	else
		return nil;
}

-(void)writeToFile:(NSString *)text withFileName:(NSString *)filePath
{
	NSMutableArray *array=[[NSMutableArray alloc] init];
	
	[array addObject:text];
	[array writeToFile:filePath atomically:YES];
	[array release];
}


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch 
	
	[[UIApplication sharedApplication] setStatusBarHidden:YES];
	//[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleBlackOpaque];
	
	[self returnWindow];
	window.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"Default.png"]];
	[self getUserDefaults];
	
	BOOL isSelected;
	
	//NSLog(@"Default of boolean is:%d",isSelected);
	
	NSString *fileName=[[self documentsPath] stringByAppendingPathComponent:@"startedCount.txt"];
	//[self writeToFile:[NSString stringWithFormat:@"%d",1] withFileName:fileName];
	NSString *fileContent=[self readFromFile:fileName];
	NSLog(@"FileContent:%@",fileContent);

//	if([fileContent isEqualToString:[NSString stringWithFormat:@"%d",1]])
//	{
//		isSelected=YES;
//	}

	if(fileContent==NULL)
	{
		isSelected=YES;
	}
	else
	{
		isSelected=[self getSelectedUserDefaults];
	}
	
		if(isSelected)
		{
			_beginVC=[[BeginViewController alloc] init];
			[window addSubview:_beginVC.view];
		}
		
		else
		{
			MainViewController *_mainVC=[[MainViewController alloc] init];
			[window addSubview:_mainVC.view];
			[_mainVC release];
		}

	[window makeKeyAndVisible];
}

-(void)setUserDefaults:(NSNumber *)imageNumber
{	
	[[NSUserDefaults standardUserDefaults] setObject:imageNumber forKey:kBackgroundImageKey];
	[[NSUserDefaults standardUserDefaults] synchronize];
}

-(void)getUserDefaults
{
	UIColor *colors[9]={
		[UIColor colorWithPatternImage:[UIImage imageNamed:@"c11.png"]],
		[UIColor colorWithPatternImage:[UIImage imageNamed:@"c12.png"]],[UIColor colorWithPatternImage:[UIImage imageNamed:@"c13.png"]],
		[UIColor colorWithPatternImage:[UIImage imageNamed:@"c21.png"]],[UIColor colorWithPatternImage:[UIImage imageNamed:@"c22.png"]],
		[UIColor colorWithPatternImage:[UIImage imageNamed:@"c23.png"]],[UIColor colorWithPatternImage:[UIImage imageNamed:@"c31.png"]],
	[UIColor colorWithPatternImage:[UIImage imageNamed:@"c32.png"]],[UIColor colorWithPatternImage:[UIImage imageNamed:@"c33.png"]]};
	
	NSString *fileName=[[self documentsPath] stringByAppendingPathComponent:@"startedCount.txt"];
	NSString *fileContent=[self readFromFile:fileName];

	if(fileContent==NULL||[[NSUserDefaults standardUserDefaults] integerForKey:kBackgroundImageKey]==100)
	{
		//window.backgroundColor=[UIColor colorWithWhite:1 alpha:1.0];
		window.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"mature.png"]];
	}
	
	else
	{
		window.backgroundColor=colors[ [[NSUserDefaults standardUserDefaults] integerForKey:kBackgroundImageKey]];	
	}
}


-(void)setSelectedUserDefaults:(NSNumber *)number
{
	[[NSUserDefaults standardUserDefaults] setObject:number forKey:kSelectedKey];
	[[NSUserDefaults standardUserDefaults] synchronize];
}


-(BOOL)getSelectedUserDefaults
{
	NSInteger i=[[NSUserDefaults standardUserDefaults] integerForKey:kSelectedKey];
	if(i==0)
		return NO;
	else 
		return YES;
}


- (void)applicationWillTerminate:(UIApplication *)application
{
	NSString *fileName=[[self documentsPath] stringByAppendingPathComponent:@"startedCount.txt"];
	NSString *fileContent=[self readFromFile:fileName];
	int i=[fileContent intValue];
	NSLog(@"i=%d",i);
	[self writeToFile:[NSString stringWithFormat:@"%d",++i] withFileName:fileName];
	NSString *_fileContent=[self readFromFile:fileName];
	NSLog(@"修改后的文件内容是:%@",_fileContent);
}

- (void)dealloc {
    [_beginVC release];
    [window release];
    [super dealloc];
}


@end
