//
//  RootViewController.m
//  MyChineseName
//
//  Created by 818 818 on 10-9-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "FirstViewController.h"
#import "NavigationBar-CustomImage.h"
@implementation RootViewController
@synthesize _firstVC,_tabBarCtrl;

-(id)init
{
	if(self=[super init])
	{
		self.view.frame=CGRectMake(0,0,320,480);
		_firstVC=[[FirstViewController alloc] init];
		navController=[[UINavigationController alloc] initWithRootViewController:_firstVC];		
		_firstVC.m_navController=navController;
		
		//[navController.navigationBar setBackground:@"barImg1-1.png"];
//		[navController setNavigationBarHidden:YES];
		navController.navigationBar.barStyle=UIBarStyleBlackTranslucent;
		[_firstVC release];
		[self.view addSubview:navController.view];
		
	}
	return self;
}

-(void)setAlphaZero
{
	NSLog(@"透明before");
	//_tabBarCtrl=[[UITabBarController alloc] init];
	self._tabBarCtrl.tabBar.alpha=0.0;
	NSLog(@"透明后");
}

-(void)setAlphaOne
{
	_tabBarCtrl.tabBar.alpha=1.0;
}

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {

	[_firstVC release];
	[_tabBarCtrl release];
    [super dealloc];
}


@end
