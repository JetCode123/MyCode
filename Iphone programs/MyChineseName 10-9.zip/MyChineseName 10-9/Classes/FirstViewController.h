//
//  FirstViewController.h
//  MyChineseName
//
//  Created by 818 818 on 10-7-26.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate>{
	
	UITableView *m_tableView;
	UISearchBar *m_search;
	
	UINavigationController *m_navController;	
	NSDictionary *allNames;
	NSMutableDictionary *names;
	NSMutableArray *keys;
	
	BOOL isSearching;
	UILabel *_label;
	
//	UINavigationBar *__firstBar;
//	UILabel *allNamesLabel;
	UILabel *searchingLabel;
}

@property (nonatomic,retain) UITableView *m_tableView;

@property(nonatomic,retain) UINavigationController *m_navController;

@property(nonatomic,retain) NSDictionary *allNames;

@property(nonatomic,retain) NSMutableDictionary *names;
@property(nonatomic,retain)NSMutableArray *keys;



-(void)resetSearch;

-(void)handleSearchForTerm:(NSString *)searchTerm;

//-(void)disappearSearchBar;
@end
