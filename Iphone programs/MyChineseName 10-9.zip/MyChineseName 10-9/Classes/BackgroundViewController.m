//
//  BackgroundViewController.m
//  MyChineseName
//
//  Created by 818 818 on 10-8-3.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BackgroundViewController.h"
#import "NavigationBar-CustomImage.h"
#import "MyChineseNameAppDelegate.h"
#import "WallImageView.h"

@implementation BackgroundViewController
@synthesize window;
@synthesize m_bgBarController;
@synthesize activityIndicator;

-(id)init
{
	if(self=[super init])
	{
		_wallView=[[WallImageView alloc] init];
		_wallView.image=[UIImage imageNamed:@"bgscrollview11.png"];
		_wallView.frame=CGRectMake(0,44,320,480);
		_wallView.theBack=self;
		
		UIScrollView *scrollView=[[[UIScrollView alloc] initWithFrame:CGRectMake(0,0,320,480)] autorelease];
		scrollView.delegate=self;
		scrollView.userInteractionEnabled=YES;
		scrollView.bounces=YES;
		scrollView.showsVerticalScrollIndicator=YES;
		scrollView.showsHorizontalScrollIndicator=NO;
		scrollView.contentSize=CGSizeMake(320,594);
		scrollView.contentOffset=CGPointMake((_wallView.frame.size.width-320)/2,(_wallView.frame.size.height-480)/2);
		[scrollView addSubview:_wallView];
		[self.view insertSubview:scrollView atIndex:0];
		
//		UIView *view1=[[UIView alloc] initWithFrame:CGRectMake(0,0,320,1)];
//		view1.backgroundColor= [UIColor orangeColor];
//		[scrollView addSubview:view1];
//		[view1 release];
//		
//		UIView *view2=[[UIView alloc] initWithFrame:CGRectMake(0,168,320,1)];
//		view2.backgroundColor=[UIColor orangeColor];
//		[scrollView addSubview:view2];
//		[view2 release];
//		
//		UIView *view3=[[UIView alloc] initWithFrame:CGRectMake(0,317,320,1)];
//		view3.backgroundColor=[UIColor orangeColor];
//		[scrollView addSubview:view3];
//		[view3 release];
//		
//		UIView *view4=[[UIView alloc] initWithFrame:CGRectMake(0,479,320,1)];
//		view4.backgroundColor=[UIColor orangeColor];
//		[scrollView addSubview:view4];
//		[view4 release];
		
		
		activityIndicator=[[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0,0,24.f,24.f)];
		activityIndicator.center=CGPointMake(160,230);
		activityIndicator.activityIndicatorViewStyle=UIActivityIndicatorViewStyleWhiteLarge;
		[self.view addSubview:activityIndicator];
		[activityIndicator release];
		
	}
	return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	bgBar=[[UINavigationBar alloc] initWithFrame:CGRectMake(0,0,320,44)];
	bgBar.barStyle=UIBarStyleBlackTranslucent;
	UINavigationItem *item=[[UINavigationItem alloc] initWithTitle:@"Wallpaper"];
	[bgBar setBackground:@"barImg1-1.png"];
	[bgBar pushNavigationItem:item animated:YES];
	[item release];
	
	[self.view addSubview:bgBar];   
	
//	_barCustomLabel=[[UILabel alloc] initWithFrame:CGRectMake(80,7,160,30)];
//	_barCustomLabel.text=@"Wallpaper";
//	_barCustomLabel.textColor=[UIColor cyanColor];
//	_barCustomLabel.textColor=[UIColor colorWithRed:0.0 green:0.666 blue:0.888 alpha:1.0];
//	_barCustomLabel.backgroundColor=[UIColor clearColor];
//	_barCustomLabel.textAlignment=UITextAlignmentCenter;
//	_barCustomLabel.font=[UIFont fontWithName:@"AmericanTypewriter-Bold" size:23.f];
//	[bgBar addSubview:_barCustomLabel];
//	[_barCustomLabel release];
	
	[bgBar release];
	
}


-(void)startAnimating
{
	[activityIndicator startAnimating];
}

-(void)stopAnimating
{
	[activityIndicator stopAnimating];
}

#pragma mark -
#pragma mark scrollviewdelegate

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
	[_wallView setUserInteractionEnabled:NO];
}
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	[_wallView setUserInteractionEnabled:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
	
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[activityIndicator release];
	[window release];
	[m_bgBarController release];
    [super dealloc];
}


@end
