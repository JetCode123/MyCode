//
//  BeginViewController.m
//  MyChineseName
//
//  Created by 818 818 on 10-9-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.		NSFileManager	NSData
//

#import "BeginViewController.h"
#import "MainViewController.h"
#import "MyChineseNameAppDelegate.h"
@implementation BeginViewController

-(id)init
{
	if(self=[super init])
	{
		//[[UIApplication sharedApplication] setStatusBarHidden:YES];
		self.view.frame=[[UIScreen mainScreen] bounds];
		self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"背景.png"]];
		isSelected=YES;

		
		_scrollView=[[[UIScrollView alloc] initWithFrame:CGRectMake(0,20,320,400)] autorelease];
		_scrollView.showsVerticalScrollIndicator=YES;
		_scrollView.showsHorizontalScrollIndicator=NO;
		_scrollView.userInteractionEnabled=YES;
		_scrollView.bounces=YES;
		_scrollView.contentSize=CGSizeMake(320,480*2+5);
		[self.view addSubview:_scrollView];
		
		UIImageView *HELP1=[[UIImageView alloc] initWithFrame:CGRectMake(0,0,320,480)];
		HELP1.image=[UIImage imageNamed:@"HELP11.png"];
		[_scrollView addSubview:HELP1];
		[HELP1 release];
		
		UIImageView *HELP2=[[UIImageView alloc] initWithFrame:CGRectMake(0,480,320,480)];
		HELP2.image=[UIImage imageNamed:@"HELP22.png"];
		[_scrollView addSubview:HELP2];
		[HELP2 release];

		
		_blank=[[UIImageView alloc] initWithFrame:CGRectMake(15,430,20,20)];
		_blank.image=[UIImage imageNamed:@"没选中.png"];
		_blank.backgroundColor=[UIColor clearColor];
		_blank.userInteractionEnabled=YES;
		[self.view addSubview:_blank];
		[_blank release];
		
		_select=[[UIImageView alloc] initWithFrame:CGRectMake(15,430,20,20)];
		_select.image=[UIImage imageNamed:@"选中.png"];
		_select.backgroundColor=[UIColor clearColor];
		_select.userInteractionEnabled=YES;
		[self.view addSubview:_select];
		[_select release];
		
		_label=[[UILabel alloc] initWithFrame:CGRectMake(40,421,100,40)];
		_label.text=@"Show at launch";
		//_label.textColor=[UIColor colorWithRed:0.710 green:0.33 blue:0.10 alpha:1];
		_label.textColor=[UIColor blackColor];
		_label.font=[UIFont fontWithName:@"ArialMT" size:14.f];
		_label.textAlignment=UITextAlignmentCenter;
		_label.backgroundColor=[UIColor clearColor];
		[self.view addSubview:_label];
		[_label release];
		
		_enterButton=[UIButton buttonWithType:UIButtonTypeCustom];		
		_enterButton.frame=CGRectMake(320-50-15,425,50,30);
		[_enterButton setBackgroundImage:[UIImage imageNamed:@"enter1.png"] forState:UIControlStateNormal];
		[_enterButton setBackgroundImage:[UIImage imageNamed:@"enter2.png"] forState:UIControlStateHighlighted];
		[_enterButton addTarget:self action:@selector(enterToMain) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:_enterButton];
		
		NSNumber *num=[NSNumber numberWithInt:1];
		[(MyChineseNameAppDelegate *)[[UIApplication sharedApplication] delegate] setSelectedUserDefaults:num];
	}
	return self;
}

-(void)enterToMain
{
	MainViewController *_mainVC=[[MainViewController alloc] init];
	_mainVC.modalTransitionStyle=UIModalTransitionStyleFlipHorizontal;
	[self presentModalViewController:_mainVC animated:YES];
	[_mainVC release];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	NSNumber *num;
	int i;
	CGRect frame=CGRectMake(0,420,160,40);
	UITouch *touch=[touches anyObject];
	CGPoint pt=[touch locationInView:self.view];
	if(CGRectContainsPoint(frame, pt))
	{
		NSLog(@"select or not");
		if(isSelected)
		{
			_select.alpha=0.0;
			isSelected=NO;
			i=0;
			num=[NSNumber numberWithInt:i];
			[(MyChineseNameAppDelegate *) [[UIApplication sharedApplication] delegate] setSelectedUserDefaults:num];
		}
		else
		{
			_select.alpha=1.0;
			isSelected=YES;
			i=1;
			num=[NSNumber numberWithInt:i];
			[(MyChineseNameAppDelegate *) [[UIApplication sharedApplication] delegate] setSelectedUserDefaults:num];
		}
	}
}
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
