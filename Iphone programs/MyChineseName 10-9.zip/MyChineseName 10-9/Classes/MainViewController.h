//
//  MainViewController.h
//  MyChineseName
//
//  Created by 818 818 on 10-9-29.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MainViewController : UIViewController {

	UITabBarController *_tabBarController;
	UIWindow *window;
}


@end
