//
//  FirstViewController.m
//  MyChineseName
//
//  Created by 818 818 on 10-7-26.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "FirstViewController.h"
#import "NSDictionary-MutableDeepCopy.h"
#import "chineseName.h"
#import "NameEditViewController.h"
#import "NavigationBar-CustomImage.h"


@implementation FirstViewController
@synthesize m_tableView;
@synthesize m_navController;

@synthesize allNames;
@synthesize keys;
@synthesize names;


-(void)resetSearch
{
	NSMutableDictionary *allNamesCopy=[self.allNames mutableDeepCopy];
	self.names=allNamesCopy;
	NSLog(@"self.names count=%d",[self.names count]);
	[allNamesCopy release];
	
	NSMutableArray *keyArray=[[NSMutableArray alloc] init];
	[keyArray addObject:UITableViewIndexSearch];
	[keyArray addObjectsFromArray:[[self.allNames allKeys] sortedArrayUsingSelector:@selector(compare:)]];
	[keyArray addObject:[NSString stringWithFormat:@"#"]];
	self.keys=keyArray;
	[keyArray release];
}

-(void)handleSearchForTerm:(NSString *)searchTerm
{
	NSLog(@"searchTerm:%@",searchTerm);
	NSString *inputCharString=[searchTerm substringFromIndex:0];
	NSLog(@"inputCharString:%@",inputCharString);
	
	NSMutableArray *sectionsToRemove=[[NSMutableArray alloc] init];
	[self resetSearch];
	
	for(NSString *key in self.keys)
	{
		NSMutableArray *nameArray=[names valueForKey:key];
		NSMutableArray *toRemove=[[NSMutableArray alloc] init];
		for(NSString *name in nameArray)
		{
			if([name hasPrefix:inputCharString]==TRUE)
			{
				if([name rangeOfString:searchTerm options:NSCaseInsensitiveSearch].location==NSNotFound)
					[toRemove addObject:name];
			}
			
			else
			{
				[toRemove addObject:name];
				
			}
		}
		
		if([nameArray count]==[toRemove count])
			[sectionsToRemove addObject:key];
		
		[nameArray removeObjectsInArray:toRemove];
		[toRemove release];
	}	
	[self.keys removeObjectsInArray:sectionsToRemove];
	[sectionsToRemove release];
	[m_tableView reloadData];
}


-(id)init
{
	if(self=[super init])
	{	
		NSLog(@"FirstViewController.view.frame=(%.f,%.f,%.f,%.f)",self.view.frame.origin.x,self.view.frame.origin.y,self.view.frame.size.width,self.view.frame.size.height);
		self.navigationItem.title=@"All Names";
		
//		__firstBar=[[UINavigationBar alloc] init];
//		__firstBar.frame=CGRectMake(0,0,320,44);
//		
//		__firstBar.barStyle=UIBarStyleBlackTranslucent;
//		UINavigationItem *item=[[UINavigationItem alloc] initWithTitle:@"All Names"];
//		[__firstBar pushNavigationItem:item animated:YES];
//		[item release];
//		[__firstBar setBackground:@"barImg1-1.png"];
//		[self.view addSubview:__firstBar];
//		[self.view bringSubviewToFront:__firstBar];
//		[__firstBar release];
		
//		allNamesLabel=[[UILabel alloc] initWithFrame:CGRectMake(80,7,160,30)];
//		allNamesLabel.text=@"All Names";
//		allNamesLabel.textColor=[UIColor colorWithRed:0.0 green:0.666 blue:0.888 alpha:1.0];
//		allNamesLabel.backgroundColor=[UIColor clearColor];
//		allNamesLabel.textAlignment=UITextAlignmentCenter;
//		allNamesLabel.font=[UIFont fontWithName:@"AmericanTypewriter-Bold" size:23.f];
//		[__firstBar addSubview:allNamesLabel];
//		[allNamesLabel release];
	
		
		self.view.frame=[[UIScreen mainScreen] bounds];
		m_tableView=[[UITableView alloc] initWithFrame:CGRectMake(0,44,320,367) style:UITableViewStylePlain];
//		m_tableView.contentSize=CGSizeMake(320,480);
		
		m_tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;
		m_tableView.separatorColor=[UIColor lightGrayColor];
		m_tableView.alpha=0.55;
		m_tableView.delegate=self;
		m_tableView.dataSource=self;
		m_tableView.rowHeight=50.f;
		
		m_search=[[UISearchBar alloc] initWithFrame:CGRectMake(0,0,320,40)];
		m_search.delegate=self;
		
		UITextField *textField=[[m_search subviews] lastObject];
		NSLog(@"searchBar.textField.frame=(%.2f,%.2f,%.2f,%.2f)",textField.frame.origin.x,textField.frame.origin.y,textField.frame.size.width,textField.frame.size.height);
		textField.returnKeyType=UIReturnKeyDone;

		searchingLabel=[[UILabel alloc] initWithFrame:CGRectMake(28,5,80,22)];
		searchingLabel.backgroundColor=[UIColor clearColor];
		searchingLabel.text=@"Searching";
		searchingLabel.textColor=[UIColor colorWithRed:0.88 green:0.10 blue:0.20 alpha:1.0];
		searchingLabel.font=[UIFont fontWithName:@"AmericanTypewriter-Bold" size:15.f];
		searchingLabel.textAlignment=UITextAlignmentCenter;
		
		[textField addSubview:searchingLabel];
		[searchingLabel release];
		
//		m_search.placeholder=@"Searching";
		m_search.barStyle=UIBarStyleBlackTranslucent;
		m_tableView.tableHeaderView=m_search;
		
		[self.view addSubview:m_tableView];
		
		
		_label=[[UILabel alloc] initWithFrame:CGRectMake(100,90,120,80)];
		_label.backgroundColor=[UIColor clearColor];
		_label.textColor=[UIColor colorWithRed:1.0 green:0.171 blue:0.1 alpha:1.0];
		_label.font=[UIFont fontWithName:@"AmericanTypewriter-Bold" size:20.f];
		_label.textAlignment=UITextAlignmentCenter;
		[m_tableView addSubview:_label];
		[_label release];
	}
	return self;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.  
- (void)viewDidLoad {
    [super viewDidLoad];
	
	
	NSDictionary *dict=[NSDictionary dictionaryWithObjectsAndKeys:
						[chineseName findAllNamesWithSameFirstWord:@"A"],@"A",
						[chineseName findAllNamesWithSameFirstWord:@"B"],@"B",
						[chineseName findAllNamesWithSameFirstWord:@"C"],@"C",
						[chineseName findAllNamesWithSameFirstWord:@"D"],@"D",
						[chineseName findAllNamesWithSameFirstWord:@"E"],@"E",
						[chineseName findAllNamesWithSameFirstWord:@"F"],@"F",
						[chineseName findAllNamesWithSameFirstWord:@"G"],@"G",
						[chineseName findAllNamesWithSameFirstWord:@"H"],@"H",
						[chineseName findAllNamesWithSameFirstWord:@"I"],@"I",
						[chineseName findAllNamesWithSameFirstWord:@"J"],@"J",
						[chineseName findAllNamesWithSameFirstWord:@"K"],@"K",
						[chineseName findAllNamesWithSameFirstWord:@"L"],@"L",
						[chineseName findAllNamesWithSameFirstWord:@"M"],@"M",
						[chineseName findAllNamesWithSameFirstWord:@"N"],@"N",
						[chineseName findAllNamesWithSameFirstWord:@"O"],@"O",
						[chineseName findAllNamesWithSameFirstWord:@"P"],@"P",
						[chineseName findAllNamesWithSameFirstWord:@"Q"],@"Q",
						[chineseName findAllNamesWithSameFirstWord:@"R"],@"R",
						[chineseName findAllNamesWithSameFirstWord:@"S"],@"S",
						[chineseName findAllNamesWithSameFirstWord:@"T"],@"T",
						[chineseName findAllNamesWithSameFirstWord:@"U"],@"U",
						[chineseName findAllNamesWithSameFirstWord:@"V"],@"V",
						[chineseName findAllNamesWithSameFirstWord:@"W"],@"W",
						[chineseName findAllNamesWithSameFirstWord:@"X"],@"X",
						[chineseName findAllNamesWithSameFirstWord:@"Y"],@"Y",
						[chineseName findAllNamesWithSameFirstWord:@"Z"],@"Z",nil];
	
	self.allNames=dict;	
	[self resetSearch];
	
	m_search.autocapitalizationType=UITextAutocapitalizationTypeNone;
	m_search.autocorrectionType=UITextAutocorrectionTypeNo;
	[m_tableView reloadData];
}

#pragma mark mark =====
#pragma mark table view dataSource	method

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return ([self.keys count]>0)?[self.keys count]:1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if([keys count]==0)
	{
		_label.text=@"No Results";
		return 0;
	}
	
	_label.text=@"";
	
	NSString *key=[keys objectAtIndex:section];
	NSArray *nameSection=[names objectForKey:key];
	return [nameSection count];
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
	//	UIColor *altCellColor=[UIColor colorWithWhite:0.3 alpha:0.005];
	
	UIColor *altCellColor=[UIColor colorWithWhite:0.66 alpha:0.005];
	cell.backgroundColor=altCellColor;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSUInteger section=[indexPath section];
	NSUInteger row=[indexPath row];
	
	NSString *key=[keys objectAtIndex:section];
	NSArray *nameSection=[[names objectForKey:key] sortedArrayUsingSelector:@selector(compare:)];
	
	
	static NSString *identifier=@"myId";
	UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:identifier];
	if(!cell)
	{
		cell=[[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
		cell.frame=CGRectZero;
	}	
	//cell.selectionStyle=UITableViewCellSelectionStyleNone;
	NSString *blank=@"\t\t\t\t";
	
	cell.textLabel.text=[blank stringByAppendingString:[nameSection objectAtIndex:row]];
	
	//cell.fontsize=21.f
	cell.textLabel.font=[UIFont fontWithName:@"Georgia" size:22.0f];
	cell.textLabel.textColor=[UIColor blackColor];
	return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSUInteger section=[indexPath section];
	NSUInteger row=[indexPath row];
	
	NSString *key=[keys objectAtIndex:section];
	NSArray *nameSection=[[names objectForKey:key] sortedArrayUsingSelector:@selector(compare:)];
	
	NameEditViewController *m_editController=[[NameEditViewController alloc] init];
	m_editController.modalTransitionStyle=UIModalTransitionStyleCrossDissolve;
	[m_editController getLabelName:[chineseName nameTransition:[nameSection objectAtIndex:row]]];
	[m_editController getName:[nameSection objectAtIndex:row]];
	
	[self presentModalViewController:m_editController animated:YES];
	[m_editController release];	
	
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark return section header
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	if([self.keys count]>0)
	{				
		NSString *key=[self.keys objectAtIndex:section];
		if(key==UITableViewIndexSearch) 
			return nil;
		
		if( key==[NSString stringWithFormat:@"#"])
			return nil;
		
		return key; 
	}
	
	else
	{	
		
		return nil;
	}
}

-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
	if(isSearching)
		return nil;
	return self.keys;
	
}

-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
	NSString *key=[keys objectAtIndex:index];
	if(key==UITableViewIndexSearch)
	{
		[tableView setContentOffset:CGPointZero animated:NO];
		return NSNotFound;
	}
	else
		return index;
	
}


#pragma mark =====
#pragma mark searchBar delegate methods

-(void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
	isSearching=YES;
	
	[self resetSearch];
	[m_tableView reloadData];
	m_search.showsCancelButton=YES;
	[m_navController setNavigationBarHidden:YES animated:YES];
	searchingLabel.alpha=0.0;
	
//	[UIView beginAnimations:@"change frame" context:nil];
//	CGRect frame=[m_tableView frame];
//	frame.origin.y=0;						//300
//	frame.size.height=frame.size.height+44.f;			
//	[m_tableView setFrame:frame];
//	CGRect barFrame=[__firstBar frame];
//	barFrame.origin.y-=44.f;
//	[__firstBar setFrame:barFrame];
//	[UIView commitAnimations];

	[UIView beginAnimations:@"change frame" context:nil];
	CGRect frame=[m_tableView frame];
	if(frame.origin.y>0)
	{
		frame.origin.y-=44.f;
		frame.size.height+=44.f;
	}
	[m_tableView setFrame:frame];
	[UIView commitAnimations];
	
	m_tableView.scrollEnabled=NO;
	m_search.text=@"";
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
	[searchBar resignFirstResponder];	
	[self handleSearchForTerm:[searchBar text]]; 
	
	for(NSString *key in self.keys)
	{
		NSMutableArray *namesForKey=[names valueForKey:key];
		if([namesForKey containsObject:[searchBar text]])
		{
			NameEditViewController *m_editController=[[NameEditViewController alloc] init];
			m_editController.modalTransitionStyle=UIModalTransitionStyleCrossDissolve;
			[m_editController getLabelName:[chineseName nameTransition:[searchBar text]]];
			[m_editController getName:[searchBar text]];
			
			[self presentModalViewController:m_editController animated:YES];
			[m_editController release];
		}
		else
		{
			[keys removeAllObjects];
			_label.text=@"No Results";
			[m_tableView reloadData];
			[m_tableView setScrollEnabled:YES];
		}
	}
}

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchTerm
{
	if([searchTerm length]==0)
	{
		[self resetSearch];
		[m_tableView reloadData];
		return;
	}
	
	[self handleSearchForTerm:[searchBar text]];
}

-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
	searchingLabel.alpha=1.0;
	isSearching=NO;
	m_search.text=@"";
	[self resetSearch];
	[m_tableView reloadData];
	[searchBar resignFirstResponder];
	
	[m_navController setNavigationBarHidden:NO animated:YES];
	m_search.showsCancelButton=NO;
	m_tableView.scrollEnabled=YES;
	
	[UIView beginAnimations:@"restore frame" context:nil];
	CGRect frame=[m_tableView frame];
	frame.origin.y+=44.f;
	frame.size.height-=44.f;
	[m_tableView setFrame:frame];
	[UIView commitAnimations];
	
//	[UIView beginAnimations:@"restore frame" context:nil];
//	CGRect frame=[m_tableView frame];
//	frame.origin.y=44;
//	frame.size.height-=44.f;
//	[m_tableView setFrame:frame];
//	CGRect barFrame=[__firstBar frame];
//	barFrame.origin.y+=44.f;
//	[__firstBar setFrame:barFrame];
//	[UIView commitAnimations];
	
	//[self performSelector:@selector(disappearSearchBar) withObject:nil afterDelay:0.6];
}

//-(void)disappearSearchBar
//{
//	[m_tableView setContentOffset:CGPointMake(0.f,44.f) animated:YES];
//}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.		NSString
    [super didReceiveMemoryWarning];	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.		NSString
	// e.g. self.myOutlet = nil;
	self.m_tableView=nil;
	self.allNames=nil;
	self.names=nil;
	self.keys=nil;
}


- (void)dealloc {
	//
	[m_tableView release];
	[m_navController release];
	[allNames release];
	[names release];
	[keys release];
    [super dealloc];
}


@end


