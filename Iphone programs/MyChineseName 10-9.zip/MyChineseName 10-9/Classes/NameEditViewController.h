//
//  NameEditViewController.h
//  MyChineseName
//
//  Created by 818 818 on 10-8-2.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>  

@class  LabelName;
@class RootViewController;

@interface NameEditViewController : UIViewController<UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIAlertViewDelegate,UIActionSheetDelegate> {
	
	RootViewController *m_root;
	
	UINavigationBar *nameEditBar;
	LabelName *m_labelNameView;
	UIButton *flipButton;
	//UINavigationItem *item;
	UILabel *__nameLabel;
	
	UIButton *saveButton,*openButton;
	
	UIProgressView *progress;
	
	UIAlertView *alert;
	UIAlertView *alert1;
	UIActionSheet *saveSheet;
	UILabel *showLabel;
	
	UIActivityIndicatorView *ai;
}

@property(nonatomic,retain) UINavigationBar *nameEditBar;
-(void)getLabelName:(NSString *)name; 
-(void)getName:(NSString *)name;

-(void)save;

-(void)flipBack;
-(void)update:(NSTimer *)timer;




@end
