//
//  WallImageView.m
//  MyChineseName
//
//  Created by 818 818 on 10-9-14.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "WallImageView.h"
#import "BackgroundViewController.h"
#import "MyChineseNameAppDelegate.h"
@implementation WallImageView
@synthesize theBack;

- (id)init {
    if (self = [super init])
	{
        // Initialization code
		self.userInteractionEnabled=YES;
		NSNumber *i=[NSNumber numberWithInt:100];
		[(MyChineseNameAppDelegate *) [[UIApplication sharedApplication] delegate] setUserDefaults:i];
	}
    return self;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{

	[theBack startAnimating];
	NSLog(@"end touch");
	
	UITouch *touch=[touches anyObject];
	CGPoint pt=[touch locationInView:self];
	
	[self setWallpaperTheX:(NSInteger)((pt.x-6.5)/97+1.0) TheY:((NSInteger)(pt.y-31)/130+1.0)];	

}


-(void)setWallpaperTheX:(NSInteger)theX TheY:(NSInteger)theY
{
	self.userInteractionEnabled=NO;
	if((theX>=1&&theX<=3) && (theY>=1&&theY<=3))
	{
		NSString *paperName=[NSString stringWithFormat:@"c%d%d.png",theX,theY];
		NSLog(@"paperName=%@",paperName);
		wallpaperImage=[UIImage imageNamed:paperName];
		
		int i,centerX,centerY;
		i=3*theX+theY-4;
		NSNumber  *imageNumber=[NSNumber numberWithInteger:i];
	[(MyChineseNameAppDelegate *) [[UIApplication sharedApplication] delegate] setUserDefaults:imageNumber];
		
		centerX=10+43*(2*(theX-1)+1)+21*(theX-1);
		centerY=28+65*(2*(theY-1)+1)+20*(theY-1);
		
		center=CGPointMake(centerX,centerY);
		NSLog(@"center=(%.2f,%.2f)",(float)centerX,(float)centerY);
		
		if(redview1==nil)
		{
			redview1=[[UIView alloc] initWithFrame:CGRectMake(0,0,90,2)];
			redview1.center=CGPointMake(centerX,centerY-66);
			redview1.backgroundColor=[UIColor redColor];
			redview1.alpha=0.8;
			[self addSubview:redview1];
			[redview1 release];
		}
		if(redview2==nil)
		{
			redview2=[[UIView alloc] initWithFrame:CGRectMake(0,0,2,134)];
			redview2.center=CGPointMake(centerX+43+1,centerY);
			redview2.alpha=0.8;
			redview2.backgroundColor=[UIColor redColor];
			redview2.alpha=0.8;
			[self addSubview:redview2];
			[redview2 release];
		}
		if(redview3==nil)
		{
			redview3=[[UIView alloc] initWithFrame:CGRectMake(0,0,90,2)];
			redview3.center=CGPointMake(centerX,centerY+66);
			redview3.alpha=0.8;
			redview3.backgroundColor=[UIColor redColor];
			redview3.alpha=0.8;
			[self addSubview:redview3];
			[redview3 release];
		}
		if(redview4==nil)
		{
			redview4=[[UIView alloc] initWithFrame:CGRectMake(0,0,2,134)];
			redview4.center=CGPointMake(centerX-43-1,centerY);
			redview4.alpha=0.8;
			redview4.backgroundColor=[UIColor redColor];
			redview4.alpha=0.8;
			[self addSubview:redview4];
			[redview4 release];
		}
		[self performSelector:@selector(changeWindowImage) withObject:nil afterDelay:2];
	}
}

-(void)changeWindowImage
{
	self.window.backgroundColor=[UIColor colorWithPatternImage:wallpaperImage];
	[theBack stopAnimating]; 
	[self performSelector:@selector(changeIndex) withObject:nil afterDelay:1];
	
}

-(void)changeIndex
{
	[theBack.m_bgBarController setSelectedIndex:0];
	
	self.userInteractionEnabled=YES;
	redview1.alpha=0.0;
	redview1=nil;
	
	redview2.alpha=0.0;
	redview2=nil;
	
	redview3.alpha=0.0;
	redview3=nil;
	
	redview4.alpha=0.0;
	redview4=nil;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
	[theBack release];
    [super dealloc];
}


@end
