//
//  PhotoViewController.m
//  MyChineseName
//
//  Created by 818 818 on 10-10-9.
//  Copyright 2010 __MyCompanyName__. All rights reserved.UITouch 
//

#import "PhotoViewController.h"
#import "NavigationBar-CustomImage.h"
#import "QuartzCore/QuartzCore.h"

@implementation PhotoViewController
@synthesize _photoTabBarController;



-(void)displayPhotoAlbum
{
	UIImagePickerController	*imagePicker=[[UIImagePickerController alloc] init];
	if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
	{
		imagePicker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
		imagePicker.delegate=self;
		
		[self presentModalViewController:imagePicker animated:YES];
		[imagePicker release];
	}
}

-(id)init
{
	if(self=[super init])
	{
		_photoNavBar=[[UINavigationBar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
		_photoNavBar.barStyle=UIBarStyleBlackTranslucent;
//		[_photoNavBar setBackground:@"barImg11.png"];
		UINavigationItem *item=[[UINavigationItem alloc] initWithTitle:@"Photos"];
		[_photoNavBar pushNavigationItem:item animated:YES];
		[item release];
		[self.view addSubview:_photoNavBar];
		[_photoNavBar release];
		
//		_photoLabel=[[UILabel alloc] initWithFrame:CGRectMake(80,7,160,30)];
//		_photoLabel.text=@"Photos";
//		_photoLabel.textColor=[UIColor colorWithRed:0.0 green:0.666 blue:0.888 alpha:1.0];
//		_photoLabel.textAlignment=UITextAlignmentCenter;
//		_photoLabel.backgroundColor=[UIColor clearColor];
//		_photoLabel.font=[UIFont fontWithName:@"AmericanTypewriter-Bold" size:23.f];
//		[_photoNavBar addSubview:_photoLabel];
//		[_photoLabel release];
		
		UIButton *testButton=[UIButton buttonWithType:UIButtonTypeInfoDark];
		testButton.frame=CGRectMake(40, 40, 100,200);
		[testButton addTarget:self action:@selector(displayPhotoAlbum) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:testButton];
		
	}
	return self;
}

- (void)viewWillAppear:(BOOL)animated
{
	NSLog(@"PhotoViewController viewWillAppear");
	[super viewWillAppear:animated];
	[NSTimer scheduledTimerWithTimeInterval:0.15 target:self selector:@selector(displayPhotoAlbum) userInfo:nil repeats:NO];
}

-(void)viewDidLoad
{
	[super viewDidLoad];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
	[picker dismissModalViewControllerAnimated:YES];
	[self performSelector:@selector(changeIndex) withObject:nil afterDelay:0.5];
}



- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
	[picker dismissModalViewControllerAnimated:YES];
	[self.view.window setBackgroundColor:[UIColor colorWithPatternImage:image]];
	[self performSelector:@selector(changeIndex) withObject:nil afterDelay:0.5];
}

-(void)changeIndex
{
	_photoTabBarController.selectedIndex=0;
}


/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[_photoTabBarController release];
	[super dealloc];
}


@end
