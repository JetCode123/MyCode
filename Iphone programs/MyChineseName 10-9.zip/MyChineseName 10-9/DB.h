//
//  DB.h
//  MyChineseName
//
//  Created by 818 818 on 10-7-27.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PlausibleDatabase/PlausibleDatabase.h>


@interface DB : NSObject {

}

/** setup sqlite db **/
+ (PLSqliteDatabase *) setup;

/** close sqlite pointer **/
+ (void) close;

@end
