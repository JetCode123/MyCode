//
//  WeiboNavBar.m
//  AppNavigator
//
//  Created by Meng Xiangping on 5/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "WeiboNavBar.h"


@implementation WeiboNavBar


-(void) drawRect:(CGRect)rect{
  
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextDrawImage(context, CGRectMake(0, 0, self.frame.size.width, self.frame.size.height), [UIImage imageNamed:@"weibotitle.png"].CGImage);
  
}

@end
