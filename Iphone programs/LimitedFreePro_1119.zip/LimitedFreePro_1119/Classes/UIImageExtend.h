//
//  UIImageExtend.h
//  AppNavigator
//
//  Created by meng Xiangping on 11-1-19.
//  Copyright 2011 盛拓传媒. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIImage(Shadow) 


- (UIImage *)imageWithShadow;

@end
