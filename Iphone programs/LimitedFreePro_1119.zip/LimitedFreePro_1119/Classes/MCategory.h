//
//  MCategory.h
//  TimeLimitFree
//
//  Created by lujiaolong on 11-8-24.
//  Copyright 2011 SequelMedia. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MCategory : NSObject {

	NSInteger _cateID;
	NSString *_cateName;
	
	NSInteger _cateUpdateCount;
	BOOL _hasSubCategory;
}

@property (nonatomic) NSInteger _cateID;
@property (nonatomic,retain) NSString *_cateName;
@property (nonatomic) NSInteger _cateUpdateCount;
@property (nonatomic) BOOL _hasSubCategory;

@end
