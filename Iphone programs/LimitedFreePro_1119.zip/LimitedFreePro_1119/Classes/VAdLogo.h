//
//  VAdLogo.h
//  TimeLimitedFree
//
//  Created by 聂 刚 on 11-5-20.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MAd.h"
@class AppDetailsViewController;

@interface VAdLogo : UIView {
	UIButton *ui_img_view;
	MAd *mad;
	AppDetailsViewController *appDetailController;
	UIView *ui_indicatorView;
	UIActivityIndicatorView *ui_indicator;
}
@property (nonatomic,retain) AppDetailsViewController *appDetailController;
@property (nonatomic,retain) UIButton *ui_img_view;
@property (nonatomic,retain) MAd *mad;
@property (nonatomic,retain) UIView *ui_indicatorView;
@property (nonatomic,retain) UIActivityIndicatorView *ui_indicator;

-(void) bindItem;
@end
