
#ifdef DEBUG
#define CLog(format,...)NSLog(format,##_VA_ARGS_)
#else 
#define CLog(format,...)
#endif