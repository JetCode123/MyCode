//
//  MAppComment.h
//  TimeLimitFree
//
//  Created by lujiaolong on 11-8-24.
//  Copyright 2011 SequelMedia. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MAppComment : NSObject {

	NSString *_commTitle;
	NSString *_commContent;
	
	NSInteger _commGoodCount;
	NSInteger _commBadCount;

	NSString *_commPubDate;
	
	NSString *_commScore;
}

@property (nonatomic,retain) NSString *_commTitle;
@property (nonatomic,retain) NSString *_commContent;

@property (nonatomic) NSInteger _commGoodCount;
@property (nonatomic) NSInteger _commBadCount;

@property (nonatomic,retain) NSString *_commPubDate;
@property (nonatomic,retain) NSString *_commScore;

@end
