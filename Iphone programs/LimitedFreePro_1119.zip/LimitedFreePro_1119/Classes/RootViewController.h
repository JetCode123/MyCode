//
//  RootViewController.h
//  TimeLimitFree
//
//  Created by lujiaolong on 11-8-23.
//  Copyright 2011 SequelMedia. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TimeLimitedFree.h"

@class OrderView;

@interface RootViewController : TimeLimitedFree	{
	//OrderView *_ov;
	
}

-(void)paixu_Action;
-(void)pushAction;
@end
