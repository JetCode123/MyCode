//
//  VNavBar.h
//  AppNavForIphone
//
//  Created by 聂 刚 on 11-4-22.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface VNavBar : UINavigationBar {

}

@end
