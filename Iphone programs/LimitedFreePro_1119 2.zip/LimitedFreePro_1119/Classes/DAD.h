//
//  DAD.h
//  TimeLimitedFree
//
//  Created by 聂 刚 on 11-5-20.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface DAD : NSObject {

}
+ (NSMutableArray *) getADList;
+(NSInteger)getTotaolCount;
@end
