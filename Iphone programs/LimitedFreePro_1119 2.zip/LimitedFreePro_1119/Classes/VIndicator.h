//
//  VIndicator.h
//  限时免费_me
//
//  Created by lujiaolong on 11-9-13.
//  Copyright 2011 SequelMedia. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface VIndicator : UIView {
}
-(void)setSelected:(int)index;
@end
