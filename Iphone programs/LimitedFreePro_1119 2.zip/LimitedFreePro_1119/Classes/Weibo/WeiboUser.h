//
//  WeiboUser.h
//  AppNavigator
//
//  Created by Meng Xiangping on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeiboUser : NSObject {

  NSString *userID_;
  NSString *screenName_;
  NSString *profileImage_;
  
}

@property (nonatomic, retain) NSString *userID;
@property (nonatomic, retain) NSString *screenName;
@property (nonatomic, retain) NSString *profileImage; 

- (id) initWithXMLString:(NSString *) xmlString;

@end
