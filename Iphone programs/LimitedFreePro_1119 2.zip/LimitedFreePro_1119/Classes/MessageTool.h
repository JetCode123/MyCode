//
//  MessageTool.h
//  TimeLimitFree
//
//  Created by lujiaolong on 11-8-25.
//  Copyright 2011 SequelMedia. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MessageTool : UIView {

}

-(id)initWithView:(UIView *)view;
//-(id)initWithView:(UIView *)view forType:(NSString *)vType;
-(void)insertLoading:(NSString *)explain;
-(void)showLoading:(NSString *)explain;
-(void)showNetworkStatus:(BOOL)status;
-(void)hideMessage;
-(void)showLoadingStatus:(BOOL)status;
-(void)hideLoadingStatus;
-(id)initWithView:(UIView *)view forType:(NSString *)vType;

@end
