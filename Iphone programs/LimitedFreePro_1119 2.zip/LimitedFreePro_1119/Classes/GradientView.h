//
//  GradientView.h
//  LimitedFreePro
//
//  Created by lu jiaolong on 11-11-18.
//  Copyright (c) 2011年 SequelMedia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GradientView : UIView{
    CGGradientRef mGradient;
}

@end
