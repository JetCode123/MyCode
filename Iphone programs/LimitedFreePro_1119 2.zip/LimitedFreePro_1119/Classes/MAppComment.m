//
//  MAppComment.m
//  TimeLimitFree
//
//  Created by lujiaolong on 11-8-24.
//  Copyright 2011 SequelMedia. All rights reserved.
//

#import "MAppComment.h"


@implementation MAppComment

@synthesize _commTitle;
@synthesize _commContent;

@synthesize _commGoodCount;
@synthesize _commBadCount;
@synthesize _commPubDate;
@synthesize _commScore;

-(void)dealloc{
	self._commTitle = nil;
	
	self._commContent = nil;
	
	self._commPubDate = nil;
	
	[self._commScore release];
	self._commScore = nil;
	
	[super dealloc];
}

@end
