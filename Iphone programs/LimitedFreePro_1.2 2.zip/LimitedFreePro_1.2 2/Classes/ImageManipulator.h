//
//  ImageManipulator.h
//  AppNavigator
//
//  Created by meng Xiangping on 11-1-13.
//  Copyright 2011 盛拓传媒. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ImageManipulator : NSObject {

}

+(UIImage *)makeRoundCornerImage:(UIImage*)img :(int) cornerWidth :(int) cornerHeight;

@end
