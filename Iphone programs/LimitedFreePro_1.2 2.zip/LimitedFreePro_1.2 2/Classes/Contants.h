

#define KEY_POSITION @"start-position"
#define KEY_ORDER @"order"
#define KEY_TIMEOUT 15
#define page_size 50
#define ROW_HEIGHT 97
#define Key_HaveNetwork @"haveNetwork"				//有无网络
#define NETWORK_NOTIFICATION @"network_notification"//网络检测通知名称

#define WEBVIEW_NET_NOTIFICATION @"webview-notif"

#define Key_NetworkType @"network-type"		
#define ROW_HEIGHT_FOOT 35
#define KEY_CATEGORYID @"cateID"


#define Dark_Background [UIColor colorWithRed:245 / 255.0 green:245 / 255.0 blue:245 / 255.0 alpha:1.0];
#define Light_Background [UIColor colorWithRed:1 green:1 blue:1 alpha:1];

#define KEY_CATEINDEX @"category-index"
#define KEY_CATEGORY @"category"
#define KEY_CATEGORY_NAME @"categoryName"

#define KEY_DETAIL_INFO_JIANJU 18

#define AdCache @"AdCache"
#define FirstPageAdCache @"firstPageAdCache"

// Title ad wei.

#define kLeftMargin 5					   //25
#define kTitleADSizeWidthHeight 74        //66
#define kDistanceBetween 20              //36

#define kTotalPageCount @"totalPage"
#define kStartPosition @"startPosition"

#define KAdArray @"adArray"

#define KADVIEWHEIGHT 108				//96
#define modalViewIsOn @"modalViewIsOn"


