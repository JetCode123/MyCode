//
//  AppListBasedCell.h
//  TimeLimitFree
//
//  Created by lujiaolong on 11-8-25.
//  Copyright 2011 SequelMedia. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "MApp.h"
#import "AppListCell.h"

//@class AppListCellView;

@interface AppListBasedCell : AppListCell {

}

@end
