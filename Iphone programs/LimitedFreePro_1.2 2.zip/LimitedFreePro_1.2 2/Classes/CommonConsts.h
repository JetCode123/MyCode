#define KEY_ISFREE @"isFree"
#define KEY_ISIPAD @"isIPad"
#define KEY_ORDER @"order"
#define KEY_CATEGORYID @"cateID"
#define KEY_CATEGORY_NAME_STR @"cateNameStr"
#define KEY_KEYWORD @"keyword"
#define KEY_TAGID @"tagid"

#define KEY_CHANNEL @"channel"

#define CHANNEL_HOTAPP @"hotApp"
#define CHANNEL_LIMITEDFREE @"limitedFree"
#define CHANNEL_PREREQUISITE @"prerequisite"
#define CHANNEL_FASTESTRISING @"FastestRising"

#define LOCATED_CATETAGINDEX @"locatedCateTagIndex"
#define LOCATED_TAGINDEX @"locatedTagIndex"
#define LOCATED_CATEINDEX @"locatedCateIndex"
#define LOCATED_INDEX @"locatedIndex"

#define KEY_CATEGORY @"category"
#define KEY_CATEGORY_NAME @"categoryName"

#define KEY_TAGIDLIST @"tagidlist"
#define KEY_TAG_NAMELIST @"tagNamelist"

#define KEY_FAVORATE_LIST @"favorateList"

#define Page_Size 18
#define ROW_HEIGHT 70
#define P_LAST_CONDITION @"lastCondition"
#define HIDE_TABBAR @"hidetabbar"
#define ExitTime @"exittimes"
#define DIDRECEIVEMEMORYWARNING @"didReceiveMemoryWarning"
#define CHANGESETTING @"changeSetting"
#define AdCache @"AdCache"
#define NETStatus @"netStatus"
#define IsFirstLoad @"IsFirstLoad"
#define PHONE_NUMBER @"phone_number"//电话号码
#define NETWORK_NOTIFICATION @"network_notification"//网络检测消息

#define SHOW_ITEMCOUNT 10//显示的数量
#define TOOL_HEIGHT 50//最新、最热、推荐切换菜单的高度
