//
//  WeiboNavBar.h
//  AppNavigator
//
//  Created by Meng Xiangping on 5/30/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface WeiboNavBar : UINavigationBar {
    
}

@end
